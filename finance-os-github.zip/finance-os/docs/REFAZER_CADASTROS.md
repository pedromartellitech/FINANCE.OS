# Refazer usuário e conta financeira

A ferramenta local `refazer_cadastros_finance_os.py` atende ao primeiro cadastro feito por engano. Ela exclui o administrador e **uma** conta financeira selecionada, após mostrar os dois cadastros e receber a confirmação `EXCLUIR` no terminal.

Só permite excluir a conta financeira se ela não tiver nenhuma movimentação, transferência ou compromisso vinculado. Registros estornados ou cancelados também contam como vínculo. Se houver qualquer vínculo, nenhum dos dois cadastros será excluído.

## Executar no Windows

1. Coloque o arquivo junto de `app.py` na pasta do projeto.
2. Pare o Finance OS com **Ctrl + C**.
3. Abra o Prompt e execute, com os caminhos desta instalação:

```bat
"C:\finance-os\.venv-nova\Scripts\python.exe" "C:\finance-os\refazer_cadastros_finance_os.py"
```

4. Confira o caminho do banco mostrado. A ferramenta usa a instalação real, respeitando `FINANCE_OS_DATA_DIR` quando configurado.
5. Digite o número da conta financeira criada por engano.
6. Confira o usuário, o nome da conta e o saldo inicial. Para confirmar esses dois cadastros, digite **EXCLUIR**. Qualquer outro texto cancela.
7. Aguarde a conclusão. O caminho da cópia de segurança será mostrado.
8. Reabra o aplicativo **sem `--demo`**:

```bat
"C:\finance-os\.venv-nova\Scripts\python.exe" "C:\finance-os\launcher.py"
```

Crie o usuário correto. Depois, cadastre a conta financeira correta em **Contas e categorias**.

## O que é preservado

A ferramenta não redefine o banco inteiro. Mantém outras contas, movimentações, compromissos, categorias, metas, orçamentos, configurações e o histórico anterior. Registra duas ações de exclusão na auditoria. As sessões do usuário removido deixam de ser válidas.

O backup completo, incluindo as credenciais anteriores, é feito pela API de backup do SQLite e fica em `backups-cadastros`, junto ao banco da instalação. Não é o backup JSON da interface. Guarde-o em local privado. A ferramenta aborta se não conseguir criar e verificar essa cópia.

A exclusão é atômica: falha em qualquer uma das remoções ou no registro da operação desfaz toda a transação. Os vínculos e os cadastros são revalidados antes de gravar, evitando excluir uma conta que tenha recebido registros enquanto a ferramenta estava aberta.

Para uma conta com histórico, use **Editar conta** para corrigir nome/tipo. Arquivar mantém o histórico e o saldo no consolidado; não serve para remover um saldo inicial incorreto.
