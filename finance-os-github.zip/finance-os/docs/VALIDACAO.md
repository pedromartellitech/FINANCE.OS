# Registro de validação — Finance OS 2.0

Data: **29/10/2026**. Ambiente executado: Linux, Python 3.12, Streamlit 1.66.1. Dependências de execução registradas em `requirements.lock.txt`.

## Resultado

**58 testes automatizados aprovados**, executados com `python -m pytest -q`.

| Área | Evidência verificada |
| --- | --- |
| Dinheiro | Valores brasileiros, centavos exatos, rejeição de entradas inválidas e datas de fim de mês |
| Movimentações | Receita/despesa, correção, estorno, conta arquivada e rollback em falhas |
| Transferências | Débito/crédito juntos e efeito zero sobre receitas/despesas e saldo consolidado |
| Agenda | Parcelas com soma exata, recorrência, recebimento, cancelamento, baixa e reabertura |
| Concorrência | Quatro tentativas simultâneas de baixa geram um único lançamento |
| Indicadores | Histórico anterior incluído no saldo e compromissos atrasados incluídos na projeção |
| Planejamento | Limites por categoria e aportes/retiradas sem movimentação indevida de caixa |
| CSV | Prévia, rejeição integral de arquivo com erro, deduplicação e proteção de fórmulas |
| Backup | Exportação, validação, restauração, cópia de recuperação e preservação das credenciais |
| Migração | Recuperação de baixa sem vínculo, conciliação do saldo, prévia sem escrita e rollback de referência quebrada |
| Acesso | Primeiro administrador, hash com salt, bloqueio de tentativas, troca de senha e invalidação de sessão antiga |
| Telas | As sete áreas renderizadas via AppTest, navegação, cadastro de conta, movimentação válida/inválida, baixa, reabertura, login/logout e isolamento entre demonstrações |

Também foi executada uma migração do banco fornecido no projeto original **em uma base temporária**. O saldo consolidado foi comparado ao da origem; foram conferidos backup válido, chaves estrangeiras e o hash do arquivo original inalterado. Os dados pessoais dessa base não integram a distribuição.

A compilação dos módulos Python, a consistência das dependências instaladas e a sintaxe do iniciador POSIX foram verificadas.

## Limites desta validação

- **Revisão visual em navegador:** não realizada. O ambiente de prévia disponível não tinha o runtime Streamlit necessário. As interações foram exercitadas pelo AppTest; isso não comprova aparência, acessibilidade ou comportamento em todos os navegadores e tamanhos de tela.
- **Windows/macOS:** os iniciadores foram preparados; não houve execução nesses sistemas. O runtime validado foi Python 3.12 em Linux.
- **Docker e Compose:** arquivos preparados; imagem e contêiner não foram construídos ou executados neste ambiente.
- **GitHub Actions:** workflow incluído; a execução remota dependerá do envio a um repositório. Python 3.13 é parte da matriz proposta, não um resultado já executado.
- **Carga e segurança:** não foi feito teste de carga, auditoria externa, teste de intrusão ou certificação. O escopo é uma instalação por cliente; operação pública com vários clientes requer evolução específica.

## Aceite na instalação de um cliente

Conferir o visual no navegador e no tamanho de tela usados pelo cliente, executar um ciclo real de entrada/saída/transferência, comparar um saldo conhecido e restaurar um backup em instalação separada. Validar armazenamento persistente e acesso privado caso haja hospedagem.

## Atualização AntigaFuturistica — 01/11/2026

- **58 testes automatizados passaram** novamente no tema final, incluindo navegação das sete telas, cadastro, login, movimentações, baixa e reabertura.
- O instalador foi exercitado numa cópia temporária com nome de marca personalizado, porta própria, configuração de cliente, páginas antigas e arquivos sentinela de dados e ambiente. Todos foram preservados; somente o tema, a navegação automática e literais de cor foram alterados.
- A segunda aplicação do instalador não produziu novas alterações nem novas cópias de segurança.
- As árvores sintáticas dos três arquivos Python que recebem cores foram comparadas antes e depois, normalizando apenas os literais de cor. Permaneceram equivalentes.
- A configuração `client.showSidebarNavigation = false` foi conferida no runtime Streamlit. O CSS também oculta a navegação automática sem afetar o menu próprio do aplicativo.
- Os módulos de domínio, banco, serviço, autenticação, portabilidade, formulários e inicialização foram comparados byte a byte com a base original.
- A sintaxe Python, o TOML e o SVG da capa foram verificados. As dependências do projeto são as mesmas.
- **Revisão visual em navegador pendente na instalação de destino.** Nesta sessão, a infraestrutura de prévia não continha o interpretador Python do projeto. Não houve publicação nem alteração em sistemas externos.
- Os testes desta rodada foram executados em Linux/Python 3.12. Windows e Python 3.14 devem ser conferidos na máquina do usuário.

## Ferramenta local para refazer os dois cadastros — 01/11/2026

**70 testes passaram**, com Python 3.12 em Linux: os 58 testes existentes e 12 novos casos da ferramenta `refazer_cadastros_finance_os.py`.

Os novos casos conferem exclusão seletiva, preservação de outras contas e lançamentos, backup SQLite completo, recriação do administrador, bloqueio de vínculos ativos/estornados/cancelados/transferências, mudança dos dados após a conferência, falha de backup, rollback das duas exclusões em falha, banco ausente, execução repetida e cancelamento pelo usuário.

Foi executado também um ciclo de exclusão e leitura da cópia de segurança em uma base temporária. Nenhum banco pessoal foi usado. A ferramenta não muda a interface nem os módulos financeiros existentes. A execução real em Windows/Python 3.14 permanece a conferir na instalação do usuário.
