# Finance OS · AntigaFuturistica

Atualização exclusivamente visual: fundo grafite esverdeado, tipografia clássica, detalhes de instrumentos analógicos, cobre iluminado, jade e ciano. A navegação automática das páginas antigas fica oculta; o menu próprio do aplicativo continua disponível.

## Atualizar a instalação que já funciona

1. Pare o Finance OS com **Ctrl + C**.
2. Extraia `finance-os-retrofuturista-atualizacao.zip`.
3. Copie **aplicar_visual_retrofuturista.py** e a pasta **tema-retrofuturista**, com seu conteúdo, para **C:\finance-os**, junto de `app.py`.
4. No Prompt de Comando, execute:

```bat
C:\finance-os\.venv-nova\Scripts\python.exe C:\finance-os\aplicar_visual_retrofuturista.py
```

5. Quando aparecer **Visual aplicado com sucesso**, inicie:

```bat
C:\finance-os\.venv-nova\Scripts\python.exe C:\finance-os\launcher.py --demo
```

6. Abra **http://127.0.0.1:8501** e pressione **Ctrl + F5**.

Para usar os dados reais, execute o último comando sem `--demo`.

O instalador aplica o CSS completo, ajusta as cores dos gráficos e mescla as configurações do tema. Cria uma cópia dos arquivos visuais anteriores em `backups-visuais`. Preserva textos personalizados, regras financeiras, configurações do servidor, dados e ambientes virtuais. As pastas das páginas antigas não são apagadas; a remoção do menu é visual, por configuração do Streamlit e CSS.

## Projeto completo

O ZIP completo já vem com o tema aplicado. Para uma instalação existente com personalizações locais, prefira o pacote de atualização acima.

A tipografia usa Georgia nos títulos, Consolas nas etiquetas e a fonte do sistema nos controles. Não há dependência de fontes ou imagens externas.

## Verificação

A suíte existente foi executada novamente. Consulte `docs/VALIDACAO.md` para o resultado e os limites. A revisão visual final em navegador deve ser concluída na máquina de destino: a infraestrutura de prévia desta sessão não dispunha do interpretador Python do projeto.
