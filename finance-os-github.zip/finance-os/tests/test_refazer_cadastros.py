import sqlite3

import pytest

from financeos.auth import authenticate, create_owner, has_owner
from financeos.db import Database
from financeos.domain import FinanceError, today
from financeos.service import FinanceService
import refazer_cadastros_finance_os as repair


@pytest.fixture
def setup(tmp_path):
    db = Database(tmp_path / "finance_os_v2.db")
    db.initialize()
    create_owner(db, "usuario.errado", "senha-teste-de-12-caracteres", "Meu espaço")
    service = FinanceService(db, "teste")
    account = service.create_account("Conta criada errada", "Conta digital", 45000)
    return db, service, account


def test_removes_only_reviewed_registrations_and_saves_complete_backup(setup):
    db, service, account = setup
    other = service.create_account("Conta que fica", "Dinheiro", 10000)
    cat = service.categories("Receita")[0]["id"]
    tx = service.create_transaction("Receita preservada", "Receita", 5000, other, cat, today())
    reviewed = repair.inspect_target(db, account)
    backup = repair.remove_registrations(db, account, reviewed)
    assert not has_owner(db)
    assert [r["id"] for r in service.accounts()] == [other]
    assert service.transactions()[0]["id"] == tx
    assert service.accounts()[0]["balance_cents"] == 15000
    with sqlite3.connect(backup) as restored:
        assert restored.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert restored.execute("SELECT count(*) FROM users").fetchone()[0] == 1
        assert restored.execute("SELECT count(*) FROM accounts").fetchone()[0] == 2
        assert restored.execute("SELECT count(*) FROM transactions").fetchone()[0] == 1
    create_owner(db, "usuario.correto", "outra-senha-segura-123", "Espaço correto")
    assert authenticate(db, "usuario.correto", "outra-senha-segura-123") == "usuario.correto"
    assert service.accounts()[0]["balance_cents"] == 15000


@pytest.mark.parametrize("link", ["active", "reversed", "pending", "cancelled", "transfer_destination"])
def test_blocks_any_financial_link_without_removing_owner(setup, link):
    db, service, account = setup
    income = service.categories("Receita")[0]["id"]
    expense = service.categories("Despesa")[0]["id"]
    if link in ("active", "reversed"):
        tx = service.create_transaction("Vínculo", "Receita", 100, account, income, today())
        if link == "reversed":
            service.reverse_transaction(tx)
    elif link in ("pending", "cancelled"):
        bill = service.create_obligations("Compromisso", "Despesa", 100, account, expense, today())[0]
        if link == "cancelled":
            service.cancel_obligation(bill)
    else:
        origin = service.create_account("Origem", "Conta digital", 1000)
        service.create_transaction("Transferência", "Transferência", 100, origin, None, today(), peer_account_id=account)
    with pytest.raises(FinanceError, match="vinculados"):
        repair.inspect_target(db, account)
    assert has_owner(db)
    assert any(a["id"] == account for a in service.accounts())
    assert not (db.path.parent / "backups-cadastros").exists()


def test_changed_review_is_rejected(setup):
    db, service, account = setup
    reviewed = repair.inspect_target(db, account)
    service.update_account(account, "Nome alterado depois", "Conta digital", True)
    with pytest.raises(FinanceError, match="mudaram"):
        repair.remove_registrations(db, account, reviewed)
    assert has_owner(db)
    assert service.accounts()[0]["name"] == "Nome alterado depois"


def test_backup_failure_prevents_any_deletion(setup, monkeypatch):
    db, service, account = setup
    reviewed = repair.inspect_target(db, account)
    def fail(_):
        raise OSError("Falha simulada ao salvar backup")
    monkeypatch.setattr(repair, "save_backup", fail)
    with pytest.raises(OSError):
        repair.remove_registrations(db, account, reviewed)
    assert has_owner(db)
    assert service.accounts()[0]["id"] == account


def test_error_inside_transaction_rolls_back_both_deletions(setup, monkeypatch):
    db, service, account = setup
    reviewed = repair.inspect_target(db, account)
    def fail(*args, **kwargs):
        raise sqlite3.IntegrityError("Falha simulada de auditoria")
    monkeypatch.setattr(FinanceService, "_audit", fail)
    with pytest.raises(sqlite3.IntegrityError):
        repair.remove_registrations(db, account, reviewed)
    assert has_owner(db)
    assert service.accounts()[0]["id"] == account
    assert len(list((db.path.parent / "backups-cadastros").glob("*.db"))) == 1


def test_missing_database_is_not_created(tmp_path):
    db = Database(tmp_path / "nao-existe.db")
    with pytest.raises(FinanceError, match="Não foi encontrado"):
        repair.inspect_target(db, 1)
    assert not db.path.exists()


def test_repeating_does_not_remove_another_account(setup):
    db, service, account = setup
    other = service.create_account("Outra conta", "Dinheiro", 300)
    reviewed = repair.inspect_target(db, account)
    repair.remove_registrations(db, account, reviewed)
    with pytest.raises(FinanceError):
        repair.remove_registrations(db, other, reviewed)
    assert [a["id"] for a in service.accounts()] == [other]


def test_user_cancellation_preserves_both(setup, monkeypatch):
    db, service, account = setup
    answers = iter(["1", "CANCELAR"])
    monkeypatch.setattr(repair, "default_database", lambda: db)
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    assert repair.main() == 0
    assert has_owner(db)
    assert service.accounts()[0]["id"] == account
    assert not (db.path.parent / "backups-cadastros").exists()
