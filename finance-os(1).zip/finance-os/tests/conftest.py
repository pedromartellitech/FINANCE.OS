import pytest

from financeos.db import Database
from financeos.service import FinanceService


@pytest.fixture
def service(tmp_path):
    db = Database(tmp_path / "finance.db")
    db.initialize()
    return FinanceService(db, "teste")


@pytest.fixture
def scenario(service):
    source = service.create_account("Principal", "Conta digital", 100000)
    target = service.create_account("Reserva", "Poupança", 0)
    income = service.categories("Receita")[0]["id"]
    expense = service.categories("Despesa")[0]["id"]
    return service, source, target, income, expense
