from datetime import date

import pytest

from financeos.domain import FinanceError, add_months, brl, legacy_cents, money_to_cents


@pytest.mark.parametrize(
    "value,cents",
    [
        ("0,01", 1),
        ("1.234,56", 123456),
        ("1234.56", 123456),
        ("R$ 10,10", 1010),
        ("12", 1200),
        ("0", 0),
    ],
)
def test_brazilian_money_is_exact(value, cents):
    assert money_to_cents(value) == cents


@pytest.mark.parametrize(
    "value", ["NaN", "Infinity", "1.005", "1,005", "1.23,45", "-1,00", "", "1e3", "0x123"]
)
def test_invalid_money_is_rejected(value):
    with pytest.raises(FinanceError):
        money_to_cents(value)


def test_negative_opening_and_formatting():
    assert money_to_cents("-1.000,01", allow_negative=True) == -100001
    assert brl(-100001) == "−R$ 1.000,01"
    assert legacy_cents(1.005) == 101


def test_month_end_keeps_original_anchor():
    base = date(2024, 1, 31)
    assert add_months(base, 1) == date(2024, 2, 29)
    assert add_months(base, 2) == date(2024, 3, 31)
