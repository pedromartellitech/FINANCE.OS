from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from financeos.auth import create_owner
from financeos.db import Database

APP = Path(__file__).resolve().parent.parent / "app.py"


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("FINANCE_OS_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("FINANCE_OS_DEMO_ONLY", "0")
    return AppTest.from_file(str(APP), default_timeout=20)


def enter_demo(app):
    app.run()
    app.button(key="enter_demo").click().run()
    assert not app.exception
    return app


def test_first_access_does_not_expose_financial_screens(app):
    app.run()
    assert len(app.radio) == 0
    assert not app.exception
    assert app.text_input(key="setup_username")


@pytest.mark.parametrize(
    "page",
    [
        "Visão geral",
        "Movimentações",
        "Agenda financeira",
        "Contas e categorias",
        "Planejamento",
        "Relatórios",
        "Dados e ajustes",
    ],
)
def test_all_views_render_in_demo_without_exceptions(app, page):
    enter_demo(app)
    app.radio(key="navigation").set_value(page).run()
    assert not app.exception
    assert not app.error


def test_creating_account_through_ui(app):
    enter_demo(app)
    app.radio(key="navigation").set_value("Contas e categorias").run()
    app.text_input(key="account_name").set_value("Conta UI")
    app.text_input(key="account_opening").set_value("125,75")
    next(b for b in app.button if b.label == "Criar conta").click().run()
    assert not app.exception
    db = Database(app.session_state["demo_db"])
    with db.read() as con:
        assert (
            con.execute("SELECT opening_cents FROM accounts WHERE name='Conta UI'").fetchone()[0]
            == 12575
        )


def test_invalid_transaction_shows_error_without_writing(app):
    enter_demo(app)
    app.radio(key="navigation").set_value("Movimentações").run()
    db = Database(app.session_state["demo_db"])
    with db.read() as con:
        before = con.execute("SELECT count(*) FROM transactions").fetchone()[0]
    app.text_input(key="tx_new_description").set_value("Teste inválido")
    app.text_input(key="tx_new_amount").set_value("1,005")
    next(b for b in app.button if b.label == "Registrar movimentação").click().run()
    assert app.error and not app.exception
    with db.read() as con:
        assert con.execute("SELECT count(*) FROM transactions").fetchone()[0] == before


def test_valid_transaction_and_logout(app):
    enter_demo(app)
    app.radio(key="navigation").set_value("Movimentações").run()
    app.text_input(key="tx_new_description").set_value("Compra pelo teste de interface")
    app.text_input(key="tx_new_amount").set_value("19,99")
    next(b for b in app.button if b.label == "Registrar movimentação").click().run()
    assert not app.exception
    assert app.success
    assert app.text_input(key="tx_new_amount").value == ""
    app.button(key="logout").click().run()
    assert not app.radio
    assert app.text_input(key="setup_username")


def test_private_setup_and_login(app):
    app.run()
    app.text_input(key="setup_username").set_value("pedro")
    app.text_input(key="setup_password").set_value("my-local-secure-password")
    app.text_input(key="setup_repeat").set_value("my-local-secure-password")
    app.text_input(key="setup_workspace").set_value("Meu negócio")
    next(b for b in app.button if b.label == "Criar meu espaço").click().run()
    assert not app.exception
    assert app.radio(key="navigation")
    app.button(key="logout").click().run()
    assert app.text_input(key="login_username")
    app.text_input(key="login_username").set_value("pedro")
    app.text_input(key="login_password").set_value("my-local-secure-password")
    next(b for b in app.button if b.label == "Entrar no Finance OS").click().run()
    assert not app.exception
    assert app.radio(key="navigation")


def test_demo_databases_are_isolated(app):
    first = enter_demo(app)
    second = AppTest.from_file(str(APP), default_timeout=20)
    enter_demo(second)
    assert first.session_state["demo_db"] != second.session_state["demo_db"]


def test_payment_and_reopening_through_ui(app):
    enter_demo(app)
    app.radio(key="navigation").set_value("Agenda financeira").run()
    db = Database(app.session_state["demo_db"])
    bill_id = app.selectbox(key="bill_action_id").value
    next(b for b in app.button if b.label == "Confirmar pagamento").click().run()
    assert not app.exception
    with db.read() as con:
        assert (
            con.execute("SELECT status FROM obligations WHERE id=?", (bill_id,)).fetchone()[0]
            == "Liquidado"
        )
    app.selectbox(key="bill_filter_status").set_value("Liquidado").run()
    app.checkbox(key="bill_reopen_confirm").set_value(True).run()
    app.button(key="bill_reopen").click().run()
    assert not app.exception
    with db.read() as con:
        assert (
            con.execute("SELECT status FROM obligations WHERE id=?", (bill_id,)).fetchone()[0]
            == "Pendente"
        )


def test_password_change_invalidates_old_session(app):
    app.run()
    app.text_input(key="setup_username").set_value("pedro")
    app.text_input(key="setup_password").set_value("my-local-secure-password")
    app.text_input(key="setup_repeat").set_value("my-local-secure-password")
    app.text_input(key="setup_workspace").set_value("Meu negócio")
    next(b for b in app.button if b.label == "Criar meu espaço").click().run()
    from financeos.auth import change_password
    from financeos.db import default_database

    change_password(
        default_database(), "pedro", "my-local-secure-password", "my-new-secure-password"
    )
    app.run()
    assert not app.exception
    assert not app.radio
    assert app.text_input(key="login_username")
    app.text_input(key="login_username").set_value("pedro")
    app.text_input(key="login_password").set_value("my-new-secure-password")
    next(b for b in app.button if b.label == "Entrar no Finance OS").click().run()
    assert not app.exception
    assert app.radio(key="navigation")
