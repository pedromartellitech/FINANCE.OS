import hashlib
import sqlite3

import pytest

from financeos.domain import FinanceError
from financeos.portability import migrate_legacy


def legacy_file(tmp_path, *, broken=False):
    path = tmp_path / "old.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE contas(id INTEGER PRIMARY KEY,nome TEXT,tipo TEXT,saldo_inicial REAL,saldo_atual REAL,ativo INTEGER);
    CREATE TABLE categorias(id INTEGER PRIMARY KEY,nome TEXT,tipo TEXT,cor TEXT,ativo INTEGER);
    CREATE TABLE lancamentos(id INTEGER PRIMARY KEY,descricao TEXT,tipo TEXT,valor REAL,conta_id INTEGER,categoria_id INTEGER,data_lancamento TEXT,data_pagamento TEXT,status TEXT,forma_pagamento TEXT,observacao TEXT);
    CREATE TABLE contas_pagar(id INTEGER PRIMARY KEY,descricao TEXT,valor REAL,conta_id INTEGER,categoria_id INTEGER,data_vencimento TEXT,data_pagamento TEXT,status TEXT,lancamento_id INTEGER,recorrente INTEGER);
    INSERT INTO contas VALUES(1,'Conta antiga','Conta Corrente',100,105,1);
    INSERT INTO categorias VALUES(1,'Vendas','Receita','#ffffff',1);
    INSERT INTO categorias VALUES(2,'Compras','Despesa','#ffffff',1);
    INSERT INTO lancamentos VALUES(1,'Entrada','Receita',20,1,1,'2025-01-01','2025-01-01','Pago','Pix','');
    INSERT INTO contas_pagar VALUES(1,'Baixa sem vínculo',15,1,2,'2025-01-02','2025-01-02','Pago',NULL,0);
    """)
    if broken:
        con.execute("UPDATE lancamentos SET conta_id=999")
    con.commit()
    con.close()
    return path


def test_migration_recovers_unlinked_payment_without_changing_balance(service, tmp_path):
    old = legacy_file(tmp_path)
    raw = old.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    report = migrate_legacy(service, raw, dry_run=True)
    assert report["contas"] == 1 and report["lancamentos"] == 2
    assert service.accounts() == []
    migrate_legacy(service, raw)
    assert service.accounts()[0]["balance_cents"] == 10500
    assert service.obligations()[0]["status"] == "Liquidado"
    assert hashlib.sha256(old.read_bytes()).hexdigest() == digest
    with pytest.raises(FinanceError):
        migrate_legacy(service, raw)


def test_migration_rolls_back_if_reference_is_broken(service, tmp_path):
    with pytest.raises(FinanceError):
        migrate_legacy(service, legacy_file(tmp_path, broken=True).read_bytes())
    assert service.accounts() == []
    assert service.transactions() == []
