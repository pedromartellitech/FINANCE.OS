import pytest

from financeos.auth import (
    authenticate,
    change_password,
    create_owner,
    has_owner,
    password_hash,
    verify_password,
)
from financeos.domain import FinanceError


def test_first_admin_and_no_default_credentials(service):
    assert not has_owner(service.db)
    create_owner(service.db, "Pedro", "my-long-secret-password", "Studio")
    assert has_owner(service.db)
    assert authenticate(service.db, "pedro", "my-long-secret-password") == "pedro"
    with pytest.raises(FinanceError):
        create_owner(service.db, "other", "my-long-secret-password", "Other")


def test_salted_passwords_and_length():
    a = password_hash("my-long-secret-password")
    b = password_hash("my-long-secret-password")
    assert a != b
    assert verify_password("my-long-secret-password", a)
    assert not verify_password("wrong-password", a)
    with pytest.raises(FinanceError):
        password_hash("123")


def test_lockout_is_persisted(service):
    create_owner(service.db, "pedro", "my-long-secret-password", "Studio")
    for _ in range(5):
        with pytest.raises(FinanceError):
            authenticate(service.db, "pedro", "incorrect")
    with pytest.raises(FinanceError, match="5 minutos"):
        authenticate(service.db, "pedro", "my-long-secret-password")


def test_change_password_requires_old_password(service):
    create_owner(service.db, "pedro", "my-long-secret-password", "Studio")
    with pytest.raises(FinanceError):
        change_password(service.db, "pedro", "wrong", "my-new-secret-password")
    change_password(service.db, "pedro", "my-long-secret-password", "my-new-secret-password")
    assert authenticate(service.db, "pedro", "my-new-secret-password") == "pedro"
