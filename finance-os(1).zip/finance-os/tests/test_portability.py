import csv
import io
import json

import pytest

from financeos.db import Database
from financeos.domain import FinanceError, today
from financeos.portability import (
    CSV_COLUMNS,
    export_backup,
    export_csv,
    import_csv,
    preview_csv,
    restore_backup,
    validate_backup,
)
from financeos.reporting import html_report
from financeos.service import FinanceService


def csv_input(s, a, inc, *, invalid=False):
    account = next(x["name"] for x in s.accounts() if x["id"] == a)
    category = next(x["name"] for x in s.categories() if x["id"] == inc)
    out = io.StringIO()
    w = csv.writer(out, delimiter=";")
    w.writerow(CSV_COLUMNS)
    w.writerow([today(), "Importado", "Receita", "123,45", account, category, "Pix", ""])
    if invalid:
        w.writerow(["inválida", "Erro", "Receita", "123,45", account, category, "Pix", ""])
    return out.getvalue().encode()


def test_csv_preview_atomic_import_and_deduplication(scenario):
    s, a, b, inc, exp = scenario
    raw = csv_input(s, a, inc)
    assert len(preview_csv(s, raw)["rows"]) == 1
    assert not s.transactions()
    assert import_csv(s, raw) == 1
    assert import_csv(s, raw) == 0
    assert s.transactions()[0]["amount_cents"] == 12345


def test_csv_with_one_error_writes_nothing(scenario):
    s, a, b, inc, exp = scenario
    with pytest.raises(FinanceError):
        import_csv(s, csv_input(s, a, inc, invalid=True))
    assert not s.transactions()


def test_csv_formula_protection_and_round_trip(scenario):
    s, a, b, inc, exp = scenario
    s.create_transaction('=HYPERLINK("x")', "Receita", 111, a, inc, today(), notes="@formula")
    raw = export_csv(s.transactions())
    assert b"'=HYPERLINK" in raw
    assert len(preview_csv(s, raw)["rows"]) == 1


def test_backup_round_trip_recovery_and_credentials_preserved(scenario):
    s, a, b, inc, exp = scenario
    from financeos.auth import create_owner, authenticate

    create_owner(s.db, "pedro", "a-strong-local-password", "Espaço teste")
    s.create_transaction("Receita", "Receita", 98765, a, inc, today())
    backup = export_backup(s)
    assert b"password_hash" not in backup
    s.create_transaction("Posterior", "Despesa", 555, a, exp, today())
    recovery = restore_backup(s, backup)
    assert recovery.exists()
    assert len(s.transactions()) == 1
    assert len(validate_backup(recovery.read_bytes())["tables"]["transactions"]) == 2
    assert authenticate(s.db, "pedro", "a-strong-local-password") == "pedro"


def test_corrupt_backup_is_rejected_before_changes(scenario):
    s, a, b, inc, exp = scenario
    payload = json.loads(export_backup(s))
    payload["tables"]["accounts"][0]["opening_cents"] = "bad"
    with pytest.raises(FinanceError):
        restore_backup(s, json.dumps(payload).encode())
    assert s.accounts()[0]["opening_cents"] == 100000


def test_backup_rejects_forged_settlement(scenario):
    s, a, b, inc, exp = scenario
    bill = s.create_obligations("Conta", "Despesa", 100, a, exp, today())[0]
    s.settle_obligation(bill, today())
    payload = json.loads(export_backup(s))
    payload["tables"]["obligations"][0]["amount_cents"] = 101
    with pytest.raises(FinanceError):
        validate_backup(json.dumps(payload).encode())


def test_html_report_escapes_user_content(scenario):
    s, a, b, inc, exp = scenario
    s.create_transaction("<script>alert('x')</script>", "Receita", 100, a, inc, today())
    report = html_report(s, today().strftime("%Y-%m")).decode()
    assert "<script>" not in report
    assert "&lt;script&gt;" in report
