from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

import pytest

from financeos.domain import FinanceError, today


def balances(s):
    return {a["id"]: a["balance_cents"] for a in s.accounts()}


def test_transactions_edits_and_reversal_reconcile(scenario):
    s, a, b, inc, exp = scenario
    income = s.create_transaction("Cliente", "Receita", 50001, a, inc, today())
    expense = s.create_transaction("Compra", "Despesa", 12345, a, exp, today())
    assert balances(s)[a] == 137656
    s.update_transaction(expense, "Compra corrigida", 20001, exp, today(), "Pix", "")
    assert balances(s)[a] == 130000
    s.reverse_transaction(income)
    assert balances(s)[a] == 79999
    assert len(s.transactions(include_reversed=True)) == 2
    with pytest.raises(FinanceError):
        s.reverse_transaction(income)


def test_transfer_is_atomic_and_neutral(scenario):
    s, a, b, inc, exp = scenario
    transfer = s.create_transaction(
        "Reserva", "Transferência", 77777, a, None, today(), peer_account_id=b
    )
    assert balances(s) == {a: 22223, b: 77777}
    assert s.summary(today().strftime("%Y-%m"))["income"] == 0
    assert s.summary(today().strftime("%Y-%m"))["expense"] == 0
    s.reverse_transaction(transfer)
    assert balances(s) == {a: 100000, b: 0}
    with pytest.raises(FinanceError):
        s.create_transaction("Inválida", "Transferência", 100, a, None, today(), peer_account_id=a)
    assert balances(s) == {a: 100000, b: 0}


def test_failed_operations_do_not_write(scenario):
    s, a, b, inc, exp = scenario
    with pytest.raises(FinanceError):
        s.create_transaction("Categoria errada", "Receita", 100, a, exp, today())
    with pytest.raises(FinanceError):
        s.create_transaction("Futuro", "Receita", 100, a, inc, today() + timedelta(days=1))
    with pytest.raises(FinanceError):
        s.create_transaction("Zero", "Receita", 0, a, inc, today())
    assert s.transactions() == []


def test_installments_keep_every_cent_and_anchor(scenario):
    s, a, b, inc, exp = scenario
    ids = s.create_obligations(
        "Notebook", "Despesa", 10000, a, exp, date(2025, 1, 31), count=3, mode="Parcelado"
    )
    rows = s.obligations()
    assert len(ids) == 3
    assert [r["amount_cents"] for r in rows] == [3334, 3333, 3333]
    assert [r["due_date"] for r in rows] == ["2025-01-31", "2025-02-28", "2025-03-31"]
    assert balances(s)[a] == 100000


def test_recurrence_repeats_amount_not_divides(scenario):
    s, a, b, inc, exp = scenario
    s.create_obligations("Internet", "Despesa", 9990, a, exp, today(), count=4, mode="Recorrente")
    assert sum(r["amount_cents"] for r in s.obligations()) == 39960


def test_settlement_reversal_and_second_settlement(scenario):
    s, a, b, inc, exp = scenario
    bill = s.create_obligations("Conta", "Despesa", 45678, a, exp, today())[0]
    tx = s.settle_obligation(bill, today())
    assert balances(s)[a] == 54322
    with pytest.raises(FinanceError):
        s.settle_obligation(bill, today())
    with pytest.raises(FinanceError):
        s.reverse_transaction(tx)
    with pytest.raises(FinanceError):
        s.update_transaction(tx, "x", 100, exp, today(), "Pix", "")
    s.reopen_obligation(bill)
    assert balances(s)[a] == 100000
    assert s.obligations()[0]["status"] == "Pendente"
    s.settle_obligation(bill, today())
    assert balances(s)[a] == 54322
    assert len(s.transactions()) == 1


def test_concurrent_settlement_happens_once(scenario):
    s, a, b, inc, exp = scenario
    bill = s.create_obligations("Concorrência", "Despesa", 2500, a, exp, today())[0]

    def settle():
        try:
            s.settle_obligation(bill, today())
            return True
        except FinanceError:
            return False

    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(lambda _: settle(), range(4)))
    assert sum(results) == 1
    assert len(s.transactions()) == 1
    assert balances(s)[a] == 97500


def test_receivable_and_cancel_do_not_double_count(scenario):
    s, a, b, inc, exp = scenario
    bill = s.create_obligations("A receber", "Receita", 30000, a, inc, today())[0]
    month = today().strftime("%Y-%m")
    assert s.summary(month)["receivable"] == 30000
    assert s.summary(month)["income"] == 0
    s.settle_obligation(bill, today())
    assert s.summary(month)["receivable"] == 0
    assert s.summary(month)["income"] == 30000
    second = s.create_obligations("Cancelar", "Despesa", 4000, a, exp, today())[0]
    s.cancel_obligation(second)
    with pytest.raises(FinanceError):
        s.settle_obligation(second, today())
    assert balances(s)[a] == 130000


def test_archival_preserves_balance_and_prevents_new_writes(scenario):
    s, a, b, inc, exp = scenario
    s.create_transaction("Entrada", "Receita", 10000, a, inc, today())
    s.update_account(a, "Principal", "Conta digital", False)
    assert s.summary(today().strftime("%Y-%m"))["balance"] == 110000
    with pytest.raises(FinanceError):
        s.create_transaction("Bloqueada", "Despesa", 100, a, exp, today())


def test_pending_obligations_prevent_archiving(scenario):
    s, a, b, inc, exp = scenario
    s.create_obligations("Conta", "Despesa", 100, a, exp, today())
    with pytest.raises(FinanceError):
        s.update_account(a, "Principal", "Conta digital", False)
    cat = next(c for c in s.categories() if c["id"] == exp)
    with pytest.raises(FinanceError):
        s.save_category(cat["name"], cat["kind"], cat["color"], exp, False)


def test_budget_and_goals_do_not_create_financial_movements(scenario):
    s, a, b, inc, exp = scenario
    month = today().strftime("%Y-%m")
    s.save_budget(exp, month, 10000)
    s.save_budget(exp, month, 15000)
    s.create_transaction("Compra", "Despesa", 5000, a, exp, today())
    assert len(s.budgets(month)) == 1
    assert s.budgets(month)[0]["spent_cents"] == 5000
    goal = s.create_goal("Reserva", 100000, today() + timedelta(days=100))
    s.contribute_goal(goal, 20000, today())
    s.contribute_goal(goal, -1000, today())
    with pytest.raises(FinanceError):
        s.contribute_goal(goal, -20000, today())
    assert s.goals()[0]["saved_cents"] == 19000
    assert balances(s)[a] == 95000


def test_daily_balance_starts_with_history(scenario):
    s, a, b, inc, exp = scenario
    s.create_transaction("Anterior", "Receita", 15000, a, inc, today() - timedelta(days=40))
    s.create_transaction("Hoje", "Despesa", 5000, a, exp, today())
    rows = s.daily_flow(today() - timedelta(days=3), today())
    assert rows[0]["balance"] == 115000
    assert rows[-1]["balance"] == 110000
    assert sum(r["expense"] for r in rows) == 5000


def test_forecast_includes_overdue_on_first_day(scenario):
    s, a, b, inc, exp = scenario
    s.create_obligations("Atrasada", "Despesa", 5000, a, exp, today() - timedelta(days=3))
    s.create_obligations("Cliente", "Receita", 20000, a, inc, today() + timedelta(days=3))
    forecast = s.forecast(7)
    assert forecast[0]["balance"] == 95000
    assert forecast[-1]["balance"] == 115000
