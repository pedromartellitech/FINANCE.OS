"""Recuperação administrativa local. Exige acesso ao diretório de dados."""

import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from financeos.auth import password_hash
from financeos.db import default_database
from financeos.domain import FinanceError
from financeos.service import FinanceService


def main():
    db = default_database()
    if not db.path.exists():
        print("Nenhuma instalação encontrada. Confira FINANCE_OS_DATA_DIR.")
        return 1
    print("Recuperação administrativa local. O acesso aos dados não será alterado.")
    username = input("Usuário do administrador: ").strip().lower()
    if input("Digite REDEFINIR para continuar: ") != "REDEFINIR":
        print("Operação cancelada.")
        return 1
    password = getpass.getpass("Nova senha (mínimo de 12 caracteres): ")
    if password != getpass.getpass("Repita a nova senha: "):
        print("As senhas não conferem.")
        return 1
    try:
        encoded = password_hash(password)
        with db.write() as con:
            row = con.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            if not row:
                raise FinanceError("Administrador não encontrado.")
            con.execute(
                "UPDATE users SET password_hash=?,failed_attempts=0,locked_until=0 WHERE id=?",
                (encoded, row[0]),
            )
            FinanceService(db, "administrador-local")._audit(
                con, "Redefinir senha", "usuário", row[0], {}
            )
        print("Senha redefinida. As sessões anteriores serão encerradas na próxima interação.")
        return 0
    except FinanceError as exc:
        print(str(exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
