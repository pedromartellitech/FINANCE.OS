@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -3 -c "import sys; assert sys.version_info >= (3,12)"
    if errorlevel 1 (
        echo Instale o Python 3.12 ou superior e tente novamente.
        pause
        exit /b 1
    )
    py -3 -m venv .venv
    if errorlevel 1 (
        echo Instale o Python 3.12 e tente novamente.
        pause
        exit /b 1
    )
)
if not exist ".venv\finance-os-installed" (
    .venv\Scripts\python.exe -m pip install -r requirements.lock.txt
    if errorlevel 1 (
        echo Nao foi possivel instalar as dependencias. Confira sua conexao.
        pause
        exit /b 1
    )
    type nul > ".venv\finance-os-installed"
)
.venv\Scripts\python.exe launcher.py %*
if errorlevel 1 pause
