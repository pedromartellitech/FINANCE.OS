# Registro de validação — Finance OS 2.0

Data: **29/10/2026**. Ambiente executado: Linux, Python 3.12, Streamlit 1.66.1. Dependências de execução registradas em `requirements.lock.txt`.

## Resultado

**58 testes automatizados aprovados**, executados com `python -m pytest -q`.

| Área | Evidência verificada |
| --- | --- |
| Dinheiro | Valores brasileiros, centavos exatos, rejeição de entradas inválidas e datas de fim de mês |
| Movimentações | Receita/despesa, correção, estorno, conta arquivada e rollback em falhas |
| Transferências | Débito/crédito juntos e efeito zero sobre receitas/despesas e saldo consolidado |
| Agenda | Parcelas com soma exata, recorrência, recebimento, cancelamento, baixa e reabertura |
| Concorrência | Quatro tentativas simultâneas de baixa geram um único lançamento |
| Indicadores | Histórico anterior incluído no saldo e compromissos atrasados incluídos na projeção |
| Planejamento | Limites por categoria e aportes/retiradas sem movimentação indevida de caixa |
| CSV | Prévia, rejeição integral de arquivo com erro, deduplicação e proteção de fórmulas |
| Backup | Exportação, validação, restauração, cópia de recuperação e preservação das credenciais |
| Migração | Recuperação de baixa sem vínculo, conciliação do saldo, prévia sem escrita e rollback de referência quebrada |
| Acesso | Primeiro administrador, hash com salt, bloqueio de tentativas, troca de senha e invalidação de sessão antiga |
| Telas | As sete áreas renderizadas via AppTest, navegação, cadastro de conta, movimentação válida/inválida, baixa, reabertura, login/logout e isolamento entre demonstrações |

Também foi executada uma migração do banco fornecido no projeto original **em uma base temporária**. O saldo consolidado foi comparado ao da origem; foram conferidos backup válido, chaves estrangeiras e o hash do arquivo original inalterado. Os dados pessoais dessa base não integram a distribuição.

A compilação dos módulos Python, a consistência das dependências instaladas e a sintaxe do iniciador POSIX foram verificadas.

## Limites desta validação

- **Revisão visual em navegador:** não realizada. O ambiente de prévia disponível não tinha o runtime Streamlit necessário. As interações foram exercitadas pelo AppTest; isso não comprova aparência, acessibilidade ou comportamento em todos os navegadores e tamanhos de tela.
- **Windows/macOS:** os iniciadores foram preparados; não houve execução nesses sistemas. O runtime validado foi Python 3.12 em Linux.
- **Docker e Compose:** arquivos preparados; imagem e contêiner não foram construídos ou executados neste ambiente.
- **GitHub Actions:** workflow incluído; a execução remota dependerá do envio a um repositório. Python 3.13 é parte da matriz proposta, não um resultado já executado.
- **Carga e segurança:** não foi feito teste de carga, auditoria externa, teste de intrusão ou certificação. O escopo é uma instalação por cliente; operação pública com vários clientes requer evolução específica.

## Aceite na instalação de um cliente

Conferir o visual no navegador e no tamanho de tela usados pelo cliente, executar um ciclo real de entrada/saída/transferência, comparar um saldo conhecido e restaurar um backup em instalação separada. Validar armazenamento persistente e acesso privado caso haja hospedagem.
