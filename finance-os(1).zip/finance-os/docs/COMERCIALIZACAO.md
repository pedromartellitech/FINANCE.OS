# Como apresentar e entregar o Finance OS

## Produto desta versão

Sistema de organização financeira gerencial para profissionais autônomos e pequenos negócios, com uma instalação independente por cliente. Pode ser entregue como código com instalação assistida, personalização visual e suporte. O uso local não exige conta em serviço externo nem integração bancária.

Esta versão não inclui emissão fiscal, contabilidade, Open Finance, conexão automática com bancos, conciliação de extratos, cobrança de assinaturas nem vários clientes no mesmo banco. O lançamento de cartão de crédito é uma forma de pagamento informativa; o sistema não monta uma fatura automaticamente.

## Demonstração de cinco minutos

1. Inicie `python launcher.py --demo` e mostre o painel: período, saldo, categorias e projeção.
2. Cadastre uma receita de serviço e mostre a atualização do resultado.
3. Agende uma despesa em três parcelas e confira que a soma corresponde ao total.
4. Dê baixa em uma parcela, mostre o lançamento gerado e desfaça a baixa.
5. Faça uma transferência entre contas e mostre que ela não altera receitas/despesas.
6. Mostre um limite por categoria, uma meta e o relatório exportável.
7. Explique backup, armazenamento local e o limite de uma instalação por cliente.

## Entrega para o primeiro cliente

- Definir o nome, a identidade visual e os fluxos que ele realmente usará.
- Registrar o escopo acordado, a licença de uso, os canais de suporte e quem cuida do backup.
- Instalar em uma máquina ou servidor privado com armazenamento persistente; criar o administrador localmente antes de qualquer exposição de rede.
- Cadastrar contas e saldos de abertura com o cliente. Testar um recebimento, um pagamento, uma transferência e um estorno com valores de homologação.
- Validar os relatórios com um período conhecido e conferir o saldo final com o cliente.
- Exportar e restaurar um backup em uma instalação separada para validar a recuperação do ambiente entregue.
- Usar dados fictícios na demonstração e no portfólio. Compartilhar a base real apenas com autorização do cliente.

## Se for hospedar

É necessário configurar HTTPS e controle de acesso do ambiente, manter o disco/volume persistente, restringir arquivos de backup, atualizar dependências e ter acompanhamento de falhas. A aplicação não configura esses serviços. O Docker e o Compose incluídos são opções de empacotamento para uma instalação; não foram executados neste ambiente de desenvolvimento.

Para uma demonstração de portfólio, use exclusivamente `FINANCE_OS_DEMO_ONLY=1`. Cada sessão usa banco temporário. Nesse modo, sair reinicia a demonstração e não há caminho para uma base privada pela interface. Um servidor público de demonstração ainda precisa de limites de uso e limpeza/observação dos recursos do host.

## Próxima etapa do produto

Após testar com um cliente piloto, priorize as melhorias a partir das tarefas dele. Para operar um serviço compartilhado com vários clientes, será necessário outro ciclo de arquitetura, segurança e operação. Não anuncie esta versão como um serviço multiempresa pronto.
