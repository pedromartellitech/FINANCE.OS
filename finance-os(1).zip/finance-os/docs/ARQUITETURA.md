# Arquitetura e decisões

Finance OS 2.0 é uma aplicação local para um administrador e um espaço financeiro por instalação. O mesmo código pode servir uma instalação privada com armazenamento persistente. Não implementa vários clientes no mesmo banco.

```mermaid
flowchart TD
  A[app.py: autenticação e sessão] --> B[Telas Streamlit]
  B --> C[FinanceService: regras e casos de uso]
  B --> D[Portabilidade e relatórios]
  C --> E[Database: transações e conexões]
  D --> E
  E --> F[SQLite: integridade e histórico]
```

## Organização

| Caminho | Responsabilidade |
| --- | --- |
| `app.py` | Login, primeiro acesso, expiração da sessão, navegação e seleção do período |
| `financeos/domain.py` | Conversão monetária, validação de datas e regras comuns |
| `financeos/db.py` | Esquema, chaves estrangeiras, conexões e transações |
| `financeos/service.py` | Movimentações, agenda, transferências, metas, orçamentos e indicadores |
| `financeos/auth.py` | Senhas com salt e PBKDF2, autenticação e bloqueio de tentativas |
| `financeos/portability.py` | CSV, backup JSON e migração do banco da versão anterior |
| `financeos/reporting.py` | Relatório HTML autônomo, com escape dos dados inseridos |
| `financeos/views/` | Telas e interação com o usuário |
| `financeos/demo.py` | Cenário fictício, com datas relativas e banco isolado por sessão |
| `assets/style.css` | Identidade visual e adaptação de layout |
| `tests/` | Regras de negócio, concorrência, migração e interação Streamlit |

## Modelo financeiro

- Todos os valores persistidos são **centavos inteiros**. O parser aceita `1.234,56` e `1234.56`; não aceita frações menores que um centavo. A conversão de valores `REAL` do sistema antigo usa `Decimal` com arredondamento explícito.
- O saldo é calculado: saldo inicial + receitas − despesas − transferências enviadas + transferências recebidas. Não há coluna de saldo atual para desatualizar.
- Uma transferência é um único registro com origem e destino, obrigatoriamente diferentes. Seu efeito consolidado é zero.
- O regime é de caixa. Uma obrigação pendente não é receita ou despesa realizada; a baixa cria o lançamento e vincula ambos na mesma transação.
- Estorno preserva a linha original. Desfazer uma baixa estorna o lançamento e reabre a obrigação.
- Metas são registros de planejamento. Aportes não reduzem o saldo das contas nem substituem transferências.
- Contas arquivadas continuam compondo o saldo consolidado e o histórico. Não recebem novas movimentações; não podem ser arquivadas enquanto houver obrigações pendentes.

## Concorrência e consistência

Escritas usam `BEGIN IMMEDIATE`, commit e rollback. Assim, duas baixas simultâneas do mesmo compromisso não geram duas despesas. Chaves estrangeiras e `CHECK` protegem os vínculos. O SQLite usa WAL e tempo de espera de 15 segundos; cada operação abre e fecha sua própria conexão. Resumos e séries históricas usam snapshots de leitura para não combinar estados de transações concorrentes.

A agenda distribui o resto da divisão nas primeiras parcelas: R$ 100,00 em três parcelas resulta em R$ 33,34 + R$ 33,33 + R$ 33,33. O dia original é a referência de cada mês: 31/01 → 28/02 → 31/03. Recorrência cria um número finito de ocorrências mensais; não existe rotina de agendamento em segundo plano.

## Dados e recuperação

CSV é uma importação de receitas/despesas realizadas, com validação completa antes da escrita e hash de cada linha. Linhas CSV idênticas são tratadas como duplicadas, inclusive dentro do mesmo arquivo. A deduplicação não compara com lançamentos manuais. Exportação CSV ignora transferências e estornados e neutraliza prefixos de fórmula de planilha.

Backup JSON inclui dados de negócio e nome do espaço, sem credenciais ou auditoria. A restauração valida estrutura, valores, datas, referências e baixas em banco temporário antes de substituir dados. Uma cópia de recuperação do estado anterior é salva antes da troca, que ocorre em uma única transação. O usuário da instalação é preservado.

A migração lê uma cópia do banco legado em modo somente leitura. Exige base financeira vazia, tem prévia e aborta integralmente em inconsistências de referência. Baixas antigas sem lançamento vinculado são recuperadas. Se o histórico não explicar o saldo atual antigo, o saldo inicial é reconciliado e isso aparece como aviso; o saldo atual informado pelo banco antigo é preservado.

## Acesso

O primeiro acesso cria um único administrador, sem senha padrão. Senhas usam salt aleatório e PBKDF2-HMAC-SHA256 com 600.000 iterações; comparações usam `hmac.compare_digest`. Cinco falhas bloqueiam novas tentativas daquela conta por cinco minutos. A sessão expira após 30 minutos sem interação ou oito horas desde o login. A demonstração nunca usa a base privada.

O login limita acesso pela aplicação; não cifra o SQLite nem protege contra alguém com acesso aos arquivos da máquina. Backup JSON também não é cifrado. A auditoria é operacional, não inviolável.

## Evolução para serviço com múltiplos clientes

O próximo salto exige isolamento por organização em todas as consultas, autorização por função, provedor de identidade com recuperação e MFA, banco apropriado para a carga esperada, cobrança e provisionamento, monitoramento e restauração validada por cliente. Esses itens não fazem parte desta versão. A fronteira comercial atual é uma instalação independente por cliente.

## Referências técnicas

- [SQLite na biblioteca padrão Python](https://docs.python.org/3/library/sqlite3.html)
- [AppTest do Streamlit](https://docs.streamlit.io/develop/api-reference/app-testing/st.testing.v1.apptest)
- [Configuração do Streamlit](https://docs.streamlit.io/develop/api-reference/configuration/config.toml)
