# Manual rápido

## Primeiro acesso

1. Execute `iniciar.bat` no Windows, ou `sh iniciar.sh` no Linux/macOS, com Python 3.12 instalado.
2. No navegador, crie um usuário, uma senha com pelo menos 12 caracteres e o nome do seu espaço.
3. Em **Contas e categorias**, cadastre ao menos uma conta. Informe o saldo anterior às movimentações que serão registradas.
4. Registre receitas e despesas em **Movimentações**, ou agende valores futuros em **Agenda financeira**.

Para apenas explorar, escolha **Explorar demonstração** na tela de entrada. Também é possível iniciar diretamente com `python launcher.py --demo`. Cada sessão de demonstração recebe seus próprios dados fictícios. As alterações são temporárias.

## Fluxos essenciais

| Quero… | Caminho |
| --- | --- |
| Registrar uma venda ou pagamento já recebido | Movimentações → Nova movimentação → Receita |
| Registrar uma compra já paga | Movimentações → Nova movimentação → Despesa |
| Mover dinheiro entre contas | Movimentações → Transferência → origem e destino |
| Agendar uma conta ou recebimento | Agenda financeira → Agendar compromisso |
| Dividir uma compra em parcelas | Agenda → Parcelado; informe o valor total e a quantidade |
| Repetir uma conta mensal | Agenda → Recorrente; informe o valor por mês e quantos meses |
| Confirmar um pagamento/recebimento | Agenda → selecionar compromisso → confirmar baixa |
| Corrigir uma baixa | Agenda → situação Liquidado → selecionar → Desfazer baixa |
| Corrigir um lançamento avulso | Movimentações → Editar ou estornar → Editar dados |
| Desfazer um lançamento avulso | Movimentações → Editar ou estornar → confirmar estorno |
| Definir limite de gastos | Planejamento → Orçamentos do mês |
| Acompanhar uma reserva | Planejamento → Metas e reservas |
| Exportar um relatório | Relatórios → CSV ou HTML para impressão |

## Entenda os indicadores

- **Saldo disponível:** todas as contas, incluindo arquivadas, considerando o histórico completo.
- **Entradas/saídas/resultado:** apenas os lançamentos ativos do mês escolhido, sem transferências.
- **A pagar/a receber:** todos os compromissos pendentes, inclusive os atrasados.
- **Projeção:** saldo de hoje somado aos recebimentos agendados e subtraído dos pagamentos agendados. Compromissos em atraso entram no primeiro dia do gráfico. Não é previsão estatística nem considera valores não cadastrados.
- **Meta:** controle manual de valores reservados. Registre uma transferência separadamente se quiser mover dinheiro para outra conta.

## Backup e restauração

Em **Dados e ajustes → Backup**, baixe o JSON e guarde uma cópia fora do computador. Esse arquivo contém os dados financeiros legíveis; armazene-o em local privado.

Para restaurar, selecione o JSON, confira a prévia e digite `RESTAURAR`. Os dados financeiros atuais serão substituídos. O usuário e a senha da instalação permanecem. A aplicação salva uma cópia anterior na subpasta `backups` do diretório de dados.

O caminho padrão do banco é `~/.finance-os/finance_os_v2.db`. No Windows, normalmente fica em `C:\Users\SEU_USUARIO\.finance-os\`. Para escolher outro caminho, defina `FINANCE_OS_DATA_DIR` no ambiente antes de iniciar o programa.

## Migrar do Finance OS anterior

1. No seu projeto antigo, localize `database/finance_os.db`. Guarde uma cópia sem alterações.
2. Abra uma instalação nova, sem contas nem movimentações.
3. Vá a **Dados e ajustes → Migrar versão antiga** e envie o arquivo.
4. Confira os totais e os avisos. O sistema pode recuperar baixas sem vínculo e reconciliar o saldo inicial para preservar o saldo atual antigo.
5. Confirme a importação. Compare os saldos com o sistema antigo e gere um backup JSON.

A migração preserva as ocorrências recorrentes já existentes. Para gerar novos meses, crie uma nova recorrência na agenda. A prévia usa uma base temporária e não altera a instalação.

## Soluções rápidas

- **Porta ocupada:** execute `python launcher.py --port 8502`.
- **CSV recusado:** baixe o modelo, mantenha as mesmas colunas, use UTF-8 e ponto e vírgula; datas são `AAAA-MM-DD`. Cadastre contas e categorias antes.
- **Conta/categoria não pode ser arquivada:** resolva ou altere seus compromissos pendentes.
- **Saldo negativo:** revise saldos iniciais e movimentações. O sistema permite saldo negativo; isso não representa crédito contratado com um banco.
- **Esqueceu a senha:** na máquina da instalação, execute `python scripts/reset_password.py` no mesmo ambiente Python do projeto e siga as perguntas. Use o mesmo `FINANCE_OS_DATA_DIR`, se personalizado. É necessário acesso ao diretório de dados. As sessões anteriores serão encerradas na próxima interação. Não apague o banco.
- **Atualização de código:** preserve o diretório de dados. Reinstale as dependências com o arquivo de versões da nova distribuição.
